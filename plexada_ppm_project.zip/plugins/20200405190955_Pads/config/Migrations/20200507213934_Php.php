<?php
use Migrations\AbstractMigration;

class Php extends AbstractMigration
{
    public function up()
    {
    }

    public function down()
    {
    }
}
