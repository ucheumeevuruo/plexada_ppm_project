<?php


namespace App\Utility\Excel;


class ExcelDocumentException extends \Exception
{

}
